/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
void display(int *b,int *a)
{
	int i;
	printf("elements of array\n");
	for(i=0;i<*a;i++)
		printf("%d\n",b[i]);
}
int accept(int a,int *n)//a=4 *n=2000 
{
	int i;
	printf("enter the elements\n");
	for(i=0;i<a;i++)
		scanf("%d",&n[i]);
}
/*void binsearch(int *c,int n)
{
	int first,last,mid,elem;
	first=0;
	last=n;
	printf("enter the element to be searched\n");
	scanf("%d",&elem);
	while(1)
	{
		mid=first+last)/2;
		if(c[mid]==elem)
		{
			printf("elem is found pos in %d\n");
			return;
		}
		else if(first>=last)
		{
			printf("not found\n");
			return;
		}
		else if(elem>c[mid])
			first=mid+1;
		else
			last=mid-1;
	}
}*/

int insert_array_pos(int *a,int n)
{
	int init_start,pos_term,i,pos,elem;
	printf("enter the pos and element to be inserted\n");
	scanf("%d%d",&pos,&elem);
	if(pos>=0 && pos<n)
	{
		init_start=n;
		pos_term=pos;
		while(1)
		{
			a[init_start]=a[init_start-1];
			init_start--;
			if(init_start==pos_term)
				break;
		}
		a[pos]=elem;
		n++;
	}
	else
		printf("enter the position within the range\n");
	return n;
}

int main()
{
	int a[20],n=0,c=0;
	while(1)
	{
	    printf("enter the coice\n 1:initialize the array elements\n2:insert elements in predefined position\n 3:display the array elements\n 4:exit\n");
	    scanf("%d",&c);
	    switch(c)
	    {
	        case 1:accept(a,&n);
	            break;
	        case 2:if(n!=0)
	                    n=inser_position(a,n);
	               else
	                    printf("insert the elements first\n");
	               break;
	        case 3:display(a,n);
	            break;
	        default:return 0;
	    }
	}
	
}
