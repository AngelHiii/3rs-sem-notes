/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

typedef struct emp
{
    char name[20];
    int age;
    float salary;
}E;

void accept(E *e1)
{
    printf("enter name age and salary\n");
    scanf("%s\n%d\n%f",e1->name,&e1->age,&e1->salary);
}

void display(E e1)
{
    printf("name=%s age=%d salary=%f",e1.name,e1.age,e1.salary);
}

int main()
{
    E e1;
    accept(&e1);
    display(e1);
}