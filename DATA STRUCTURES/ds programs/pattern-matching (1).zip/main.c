/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>

int pattern_match(char P[20],char T[20])
{
    int R,S,index,max,L,K;
    R=strlen(P);
    S=strlen(T);
    index=-1;
    max=S-R+1;
    for(K=0;K<=max;K++)
    {
        printf("-----window %d-----\n",K);
        for(L=0;L<R;L++)
        {
            printf("P[L]=%c  T[K+L]=%c \n",P[L],T[K+L]);
            printf("L=%d  K=%d\n",L,K);
            if(P[L]!=T[K+L])
                break;
        }
        printf("L=%d  R=%d\n",L,R);
        if(L==R)
            return K;
    }
    printf("none of the window matched\n");
    return -1;
}

int main()
{
    char p[]="ind",t[]="aiend xyz";
    printf("position = %d",pattern_match(p,t));
    return 0;
}
