/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>             //Pattern matching program by initialising starting position//
#include<string.h>

int pattern_match(char P[20],char T[20],int start_pos)
{
    int R,S,index,max,L,K;
    R=strlen(P);
    S=strlen(T);
    index=-1;
    max=S-R+1;
    for(K=start_pos;K<=max;K++)
    {
        printf("-----window %d-----\n",K);
        for(L=0;L<R;L++)
        {
            printf("P[L]=%c  T[K+L]=%c \n",P[L],T[K+L]);
            printf("L=%d  K=%d\n",L,K);
            if(P[L]!=T[K+L])
                break;
        }
        printf("L=%d  R=%d\n",L,R);
        if(L==R)
            return K;
    }
    printf("none of the window matched\n");
    return -1;
}

int main()
{
    char p[]="ind",t[]="a ind x ind yz";
    printf("position = %d",pattern_match(p,t,6));
    return 0;
}
