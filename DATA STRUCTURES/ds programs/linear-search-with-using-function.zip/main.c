/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int linear_search(int a[],int search,int n)
{
    for (int i = 0; i < n; i++)
    {
        if (a[i] == search)
	    {
	        printf("element found in position %d \n", i + 1);
	        return 0;
	    }
    
    }
    printf("element not found \n");
}


int main()
{
    int i,a[20],n,search,position;
    printf("enter the numbr of elements \n");
    scanf("%d",&n);
    printf("enter the elements\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    printf("enter the number to  be searched\n");
    scanf("%d",&search);
    position=linear_search(a,search,n);
}
    
