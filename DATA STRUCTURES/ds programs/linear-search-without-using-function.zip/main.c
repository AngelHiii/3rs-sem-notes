/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int main()
{
    int i,a[20],n,search,position;
    printf("enter the numbr of elements \n");
    scanf("%d",&n);
    printf("enter the elements\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    printf("enter the number to  be searched\n");
    scanf("%d",&search);
    
    
    for (i = 0; i < n; i++)
    {
        if (a[i] == search)
	    {
	        printf("element found in position %d \n", i + 1);
	        return 0;
	    }
    //return;
    }
    printf("element not found \n");
}
