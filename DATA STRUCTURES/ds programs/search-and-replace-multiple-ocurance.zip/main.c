/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

#include<string.h>          //pattern matching program--print 0 for matched,,-1 for not matching

int pattern_match(char P[20],char T[20],int start_pos)
{
    int R,S,MAX,L,K;
    R=strlen(P);  
    S=strlen(T);
    MAX=S-R;
    printf("-----window-----\n");
    for(L=0;L<R;L++,start_pos++)
    {
        printf("P[%d]=%c  T[%d]=%c\n",L,P[L],start_pos,T[start_pos]);
        if(P[L]!=T[start_pos])
            break;
    }
    printf("L=%d  R=%d\n",L,R);
    if(L==R)
        return 0;
    return -1;
}

int copy_str_match(char ostr[20],char RS[],int ostr_pos)
{
    for(int i=0;i<strlen(RS);i++,ostr_pos++)
        ostr[ostr_pos]=RS[i];
    return ostr_pos;
}
    /*T_pos=0,ostr_pos=0;
    while(T_pos<strlen(T))
    { 
        flag=pattern_match(PS,T,T_pos);
        if(flag==0)
            
        else
            
    }*/
/*int main()
{
    char p[]="ind",t[]="aindxind";
    printf("position = %d",pattern_match(p,t,1));
    return 0;
}*/


int main()
{
    char T[]="inain",PS[]="in",RS[]="ind",ostr[20]="-------------"; 
    int ostr_pos=0;
    int T_pos=0,flag;
    while(T_pos<strlen(T))
    { 
        flag=pattern_match(PS,T,T_pos);
        printf("T_pos=%d flag=%d \n",T_pos,flag);
        if(flag==-1)
        {
            printf("ostr=%s\n",ostr);
            ostr[ostr_pos]=T[T_pos];
            ostr_pos++;T_pos++;
            printf("ostr=%s  ostr_pos=%d\n",ostr,ostr_pos);
        }
            
        else
        {
            printf("ostr=%s\n",ostr);
            ostr_pos=copy_str_match(ostr,RS,ostr_pos);
            T_pos=T_pos+strlen(PS);
            printf("ostr_pos=%d  ostr=%s\n",ostr_pos,ostr);
        }
            
    }
    
   // ostr_pos=copy_str_match(ostr,RS,0);
    
    /*printf("return flag=%d",pattern_match(PS,T,2));
    if(flag==0)
    {
        printf("ostr_pos=%c\n",copy_str_match(ostr,RS,ostr_pos));
    }*/
    ostr[ostr_pos]='\0';
    printf("repl string =%s\n",ostr);
    return 0;
}


