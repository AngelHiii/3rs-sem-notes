/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>          //pattern matching program--print 0 for matched,,-1 for not matching

int pattern_match(char P[20],char T[20],int start_pos)
{
    int R,S,MAX,L,K;
    R=strlen(P);  
    S=strlen(T);
    printf("-----window-----\n");
    for(L=0;L<R;L++,start_pos++)
    {
        printf("P[%d]=%c  T[%d]=%c\n",L,P[L],start_pos,T[start_pos]);
        if(P[L]!=T[start_pos])
            break;
    }
    printf("L=%d  R=%d\n",L,R);
    if(L==R)
        return 0;
    return -1;
}
int main()
{
    char p[]="ind",t[]="aindxind";
    printf("position = %d",pattern_match(p,t,1));
    return 0;
}
