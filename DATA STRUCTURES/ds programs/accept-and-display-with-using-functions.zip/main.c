/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void accept(int b[])
{
    int i,n=4;
    printf("enter  the elements\n");
    for(i=0;i<n;i++)
        scanf("%d",&b[i]);
}

void display(int c[])
{
    int i,n=4;
    printf("elemrntd are");
    for(i=0;i<n;i++)
        printf("%d\n",c[i]);
}

int main()
{
    int a[10];
    accept(a);
    display(a);

    return 0;
}
