/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int dele_pos(int *a,int n)
{
	int init_start,pos_term,elem,pos;
	printf("enter the position\n");
	scanf("%d",&pos);
	if(pos>=0 && pos<n)
	{
		init_start=pos;
		pos_term=n;
		elem=a[pos];
		printf("element deleted is %d\n",elem);
		while(1)
		{
			a[init_start]=a[init_start+1];
			init_start++;
			if(init_start==pos_term-1)
				break;
		}
		n--;
	}
	else
		printf("enter the position value within the range\n");
	return n;
}

int display(int *b,int *a)
{
	int i;
	printf("elements of array\n");
	for(i=0;i<*a;i++)
		printf("%d\n",b[i]);
}

void accept(int a,int *n)
{
	int i;
	printf("enter the elements\n");
	for(i=0;i<a;i++)
		scanf("%d",&n[i]);
}

int inser_position(int *a,int n)
{
	int pos,elem;
	printf("enter the pos and element to be inserted\n");
	scanf("%d%d",&pos,&elem);
	int init_start=n,pos_term=pos;
	
	if(pos>=0 && pos<n)
	{
		while(1)
		{
			a[init_start]=a[init_start-1];//a[3]=a[2]
			init_start--; // init_start=2
			if(init_start==pos_term)
				break;
		}
		a[pos]=elem;
		(n)++;
	}
	else 
		printf("enter the position within the range\n");
	return n;
}

int main()
{
	int n=4,a[20]={22,33,55,66};
	//printf("enter the number of elements\n");
	//scanf("%d",&n); //4
	//accept(n,a); //4  2000
	//display(a,&n); //a  2000
	//binsearch(a,n);
	//linsearch(a,n);
	n=inser_position(a,n);
	display(a,&n);
	n=dele_pos(a,n);
	display(a,&n);
}
