/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
typedef struct emp
{
    char name[20];
    int age;
    float salary;
}E;

int main()
{
    E e1;
    scanf("%s%d%f",e1.name,&e1.age,&e1.salary);
    printf("name=%s age=%d salary=%f",(e1).name,(e1).age,(e1).salary);
}
